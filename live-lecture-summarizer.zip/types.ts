export interface KeyMoment {
  id: number;
  imageDataUrl: string;
  summary: string;
}
