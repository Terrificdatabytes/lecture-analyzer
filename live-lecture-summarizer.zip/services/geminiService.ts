import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Sends a captured frame to Gemini for analysis.
 * @param base64Image The base64 encoded image data of the frame.
 * @returns A text summary of the frame's content.
 */
export async function analyzeFrame(base64Image: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image,
            },
          },
          {
            text: 'You are an expert academic summarizer. Describe the key information presented in this frame from a lecture. Focus on text, diagrams, and core concepts shown. Be concise and clear.',
          },
        ],
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error analyzing frame with Gemini:", error);
    throw new Error("Failed to get summary from Gemini API.");
  }
}

/**
 * Sends a collection of individual frame summaries to Gemini to create a final, cohesive summary.
 * @param summaries An array of strings, where each string is a summary of a key moment.
 * @returns A single, cohesive final summary.
 */
export async function generateFinalSummary(summaries: string[]): Promise<string> {
  if (summaries.length === 0) {
    return "No key moments were provided to summarize.";
  }

  const promptContent = `
    The following are sequential summaries of key moments captured from a lecture. 
    Please synthesize them into a single, cohesive, and well-structured final summary of the entire lecture.
    Organize the information logically, perhaps using bullet points or short paragraphs for clarity.

    Key Moments:
    ${summaries.map((s, i) => `- Moment ${i + 1}: ${s}`).join('\n')}

    Final Summary:
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: promptContent,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating final summary with Gemini:", error);
    throw new Error("Failed to get final summary from Gemini API.");
  }
}
